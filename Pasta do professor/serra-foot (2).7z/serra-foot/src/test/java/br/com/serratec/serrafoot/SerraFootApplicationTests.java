package br.com.serratec.serrafoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerraFootApplicationTests {

	@Test
	void contextLoads() {
	}

}
